#include "Arrow.h"

Arrow::Arrow()
{
}

Arrow::~Arrow()
{
}
