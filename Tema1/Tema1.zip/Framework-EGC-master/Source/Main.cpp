#include <ctime>
#include <iostream>
#include <Windows.h>
#include <mmsystem.h>
using namespace std;

#include <Core/Engine.h>
#include <Laboratoare/LabList.h>

int main(int argc, char **argv)
{
	srand((unsigned int)time(NULL));

	// Create a window property structure
	WindowProperties wp;
	wp.resolution = glm::ivec2(1280, 720);
	//wp.name = "Laborator1";
	wp.name = "BowAndArrow";

	// Init the Engine and create a new window with the defined properties
	WindowObject* window = Engine::Init(wp);
	PlaySound(TEXT("C:\\Poli\\Anul3\\sem1\\EGC\\Framework-EGC-master\\Visual Studio\\legacy.wav"), NULL, SND_ASYNC);
	// Create a new 3D world and start running it
	World *world = new BowAndArrow();
	world->Init();
	world->Run();

	// Signals to the Engine to release the OpenGL context
	Engine::Exit();

	return 0;
}